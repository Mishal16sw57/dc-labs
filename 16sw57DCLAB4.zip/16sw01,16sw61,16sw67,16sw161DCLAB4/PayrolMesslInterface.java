import java.rmi.*;
import java.rmi.server.*;

public interface PayrolMesslInterface extends Remote {


 public void message(String message) throws RemoteException;
  
}