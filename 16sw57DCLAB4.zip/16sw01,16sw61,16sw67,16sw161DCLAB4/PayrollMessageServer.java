import java.rmi.*;
import java.rmi.server.*;
class PayrollMessageServer{
public static void main(String args[]){
	String name="rmi://localhost/PayrollMessage";
	try{
		Naming.rebind(name,new PayrollMessage());
		String servername="rmi://localhost/PayrollServer";
		PayrollInterface p=(PayrollInterface)Naming.lookup(servername);
		System.out.println("\n"+"Your Send  amount is: "+p.earning(5,150));
	}catch(Exception e){
       e.printStackTrace();
	}}}