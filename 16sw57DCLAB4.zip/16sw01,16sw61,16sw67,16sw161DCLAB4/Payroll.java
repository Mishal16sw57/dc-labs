import java.rmi.*;
import java.rmi.server.*;
import java.net.*;
public class Payroll extends UnicastRemoteObject implements PayrollInterface{
	private double pay;
	public Payroll() throws RemoteException{}
public double earning(int id, double hrs) throws RemoteException{
	if (id==1)
		pay=10*hrs;
	else if(id>1)
		pay=100*hrs;
	String ClientService="rmi://localhost/PayrollMessage";
	try{
		PayrolMesslInterface p=(PayrolMesslInterface)Naming.lookup(ClientService);
		p.message("Hi Fawad ready to send amount to Sanjay ");
	}catch(Exception e){e.printStackTrace();}
	return pay;

}
}