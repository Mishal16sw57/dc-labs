import java.rmi.*;
import java.rmi.server.*;

public interface PayrollInterface extends Remote {


 public double earning(int id, double hrs) throws RemoteException;
  
}