import java.rmi.*;
import java.rmi.server.*;
class PayrollServer{
	public static void main(String args[]){
try{
	Naming.rebind("rmi://localhost/PayrollServer",new Payroll());
	System.out.println("Server is ready");
	}catch(Exception e){
		System.out.println("Server is failed"+e);
	}
}
}