import java.rmi.*;
import java.rmi.server.*;
import java.net.*;
public class PayrollMessage extends UnicastRemoteObject implements PayrolMesslInterface{
	public PayrollMessage() throws RemoteException{}
	public void message(String message) throws RemoteException{
		System.out.println("Message from Server: "+message);
	}
}