import java.util.Random;
import static java.util.concurrent.TimeUnit.NANOSECONDS;

public class MatrixMul1 {
    static long startTime = System.nanoTime();
    
    static int[][] mat = new int[10][10];
    static int[][] mat2 = new int[10][10];
    static int[][] result = new int[10][10];

    public static void main(String [] args){
        
        //Creating the object of random class
        Random rand = new Random();
        
        
        //Filling first matrix with random values
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                mat[i][j]=rand.nextInt(10);
            }
        }
        
        //Filling second matrix with random values
        for (int i = 0; i < mat2.length; i++) {
            for (int j = 0; j < mat2[i].length; j++) {
                mat2[i][j]=rand.nextInt(10);
            }
        }

        //Printing the first matrix
        System.out.println("This is first matrix:");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }

        //Printing the second matrix
        System.out.println("\nThis is second matrix:");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat2[i][j]+" ");
            }
            System.out.println();
        }

        try{
            //Object of multiply Class
            Multiply multiply = new Multiply(10,10);
            
            //Threads
            MatrixMultiplier thread1 = new MatrixMultiplier(multiply);
            MatrixMultiplier thread2 = new MatrixMultiplier(multiply);
            MatrixMultiplier thread3 = new MatrixMultiplier(multiply);
                   MatrixMultiplier thread4 = new MatrixMultiplier(multiply);
            MatrixMultiplier thread5 = new MatrixMultiplier(multiply);
            MatrixMultiplier thread6 = new MatrixMultiplier(multiply);
                   MatrixMultiplier thread7 = new MatrixMultiplier(multiply);
            MatrixMultiplier thread8 = new MatrixMultiplier(multiply);
            MatrixMultiplier thread9 = new MatrixMultiplier(multiply);
               MatrixMultiplier thread10 = new MatrixMultiplier(multiply);
            
            //Implementing threads
            Thread th1 = new Thread(thread1);
            Thread th2 = new Thread(thread2);
            Thread th3 = new Thread(thread3);
              Thread th4 = new Thread(thread4);
            Thread th5 = new Thread(thread5);
            Thread th6 = new Thread(thread6);

                      Thread th7 = new Thread(thread7);
            Thread th8 = new Thread(thread8);
            Thread th9 = new Thread(thread9);
                 Thread th10 = new Thread(thread10);
            
            //Starting threads
            th1.start();
            th2.start();
            th3.start();
             th4.start();
            th5.start();
            th6.start();
             th7.start();
            th8.start();
            th9.start();
             th10.start();
            
            th1.join();
            th2.join();
            th3.join();
            th4.join();
            th5.join();
            th6.join();
            th7.join();
            th8.join();
            th9.join(); 
            th10.join();
            
        }catch (Exception e) {
            e.printStackTrace();
        }

        //Printing the result
        System.out.println("\n\nResult:");
        for (int i = 0; i < result.length; i++) {
            for (int j = 0; j < result[i].length; j++) {
                System.out.print(result[i][j]+" ");
            }
            System.out.println();
        }

 long endTime   = System.nanoTime();
       long totalTime = endTime - startTime;
       
       //double time = totalTime/1000000000;
       //double timeInSeconds = time/10;
       System.out.println("Time: "+totalTime);

    }//End main

}//End Class

//Multiply Class
class Multiply extends MatrixMul1 {
    
    private int i;
    private int j;
    private int chance;
    
    public Multiply(int i, int j){
        this.i=i;
        this.j=j;
        chance=0;
    }
    
    //Matrix Multiplication Function
    public synchronized void multiplyMatrix(){
        
        int sum=0;
        int a=0;
        for(a=0;a<i;a++){
            sum=0;
            for(int b=0;b<j;b++){
                sum=sum+mat[chance][b]*mat2[b][a];
            }
            result[chance][a]=sum;
        }
        
        if(chance>=i)
            return;
        chance++;
    }
}//End multiply class

//Thread Class
class MatrixMultiplier implements Runnable {
    
    private final Multiply mul;
    
    public MatrixMultiplier(Multiply mul){
        this.mul=mul;
    }

    @Override
    public void run() {
        mul.multiplyMatrix();
    }
}