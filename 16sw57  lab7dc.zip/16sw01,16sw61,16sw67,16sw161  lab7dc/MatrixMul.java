import java.util.Scanner;
import static java.util.concurrent.TimeUnit.NANOSECONDS;
import java.util.Random;


public class MatrixMul {
    static long startTime = System.nanoTime();
    
    static int[][] mat = new int[10][10];
    static int[][] mat2 = new int[10][10];
    static int[][] result = new int[10][10];

    public static void main(String[] args) {
    
        Random rand = new Random();
      //Filling first matrix with random values
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                mat[i][j]=rand.nextInt(10);
            }
        }
        
        //Filling second matrix with random values
        for (int i = 0; i < mat2.length; i++) {
            for (int j = 0; j < mat2[i].length; j++) {
                mat2[i][j]=rand.nextInt(10);
            }
        }

        //Printing the first matrix
        System.out.println("This is first matrix:");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j]+" ");
            }
            System.out.println();
        }

        //Printing the second matrix
        System.out.println("\nThis is second matrix:");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat2[i][j]+" ");
            }
            System.out.println();
        }

        System.out.println("\n\nResult:");
        

        for(int i=0;i<10;i++){    
          for(int j=0;j<10;j++){    
            result[i][j]=0;      
            for(int k=0;k<10;k++)      
            {      
              result[i][j]+=mat[i][k]*mat2[k][j];    } 
                System.out.print(result[i][j]+" ");  }
                System.out.println();  }    
        long endTime   = System.nanoTime();
       long totalTime = endTime - startTime;
      System.out.println("Time: " + totalTime);} }

