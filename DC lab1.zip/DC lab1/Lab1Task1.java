import java.net.*;
import java.io.*;
public class Lab1Task1{
	public static void main(String[] args){
		  // this application sends message using connectionless datagram socket
	 if(args.length!=6)
		 System.out.println("this program requires six command line arguments");
	 else{
		 try{
		 	InetAddress receiverHost=InetAddress.getByName(args [0]);
			int receiverPort= Integer.parseInt(args [1]);
			String message=args[2];
			DatagramSocket mySocket=new DatagramSocket();
			byte[] buffer=message.getBytes();
			DatagramPacket datagram=new DatagramPacket(buffer,buffer.length,receiverHost,receiverPort);
			mySocket.send(datagram);
			mySocket.close();
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }
		 try{
		 	InetAddress receiverHost1=InetAddress.getByName(args[3]);
		 	int receiverPort1= Integer.parseInt(args [4]);
		 	String mess1=args[5];
			DatagramSocket mySocket1=new DatagramSocket();
			byte[] buffer1=mess1.getBytes();
			DatagramPacket datagram1=new DatagramPacket(buffer1,buffer1.length,receiverHost1,receiverPort1);
		mySocket1.send(datagram1);
			mySocket1.close();
		 }
		 catch(Exception e){
		 	e.printStackTrace();
		 }
	 }  } }