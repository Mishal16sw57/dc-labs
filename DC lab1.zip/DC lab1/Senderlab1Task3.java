import java.net.*;
import java.io.*;
public class Senderlab1Task3 {
	public static void main(String[] args){
		
	 if(args.length!=7)
		 System.out.println("this program requires seven command line arguments");
	 else{
	 while(true){
		 try{
		 InetAddress receiverHost=InetAddress.getByName(args [0]);
			int receiverPort= Integer.parseInt(args [1]);
			String message=args[2];
			String message1=args[3];
			String message2=args[4];
			String message3=args[5];
			StringBuffer sb=new StringBuffer();
			sb.append(message+" ");
			sb.append(message1+" ");
			sb.append(message2+" ");
			sb.append(message3+" ");
			String ms=new String(sb);
			DatagramSocket mySocket=new DatagramSocket();
			byte[] buffer=message.getBytes();
			DatagramPacket datagram=new DatagramPacket(buffer,buffer.length,receiverHost,receiverPort);
			mySocket.send(datagram);
			mySocket.close();
			int port1=Integer.parseInt(args[6]);
			final int MAX_LEN=100;
				DatagramSocket mySocket1=new DatagramSocket(port1);
			byte[] buffer1=new byte[MAX_LEN];
			DatagramPacket dp=new DatagramPacket(buffer1,MAX_LEN);
			mySocket1.receive(dp);
			String message4=new String(buffer1);
			System.out.println(message4);
			Thread.sleep(10000);
			System.out.println("Existing");
			mySocket1.close();}

		 catch(Exception e){
			 e.printStackTrace();}
		 
	 }  } }}