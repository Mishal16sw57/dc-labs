import java.net.*;
import java.io.*;
public class Lab1Task2{
	public static void main(String[] args){
		  // this application sends message using connectionless datagram socket
	 if(args.length!=3)
		 System.out.println("requires 3 command line arguments");
	 else{
		 try{
		 	InetAddress receiverHost=InetAddress.getByName(args [0]);
			int receiverPort= Integer.parseInt(args [1]);
			String message=args[2];
			DatagramSocket mySocket=new DatagramSocket();
			byte[] buffer=message.getBytes();
			DatagramPacket datagram=new DatagramPacket(buffer,buffer.length,receiverHost,receiverPort);
			mySocket.send(datagram);
			mySocket.close();
		 }
		 catch(Exception e){
			 e.printStackTrace();
		 }}}}