import java.io.*;
import java.net.*;
public class ChatServer{
  public static void main(String[] args) throws Exception{
      ServerSocket sersock = new ServerSocket(3000);
      System.out.println("Server  ready for chatting");
      Socket sock = sersock.accept( );                          
                              // reading from keyboard (keyRead object)
      BufferedReader kRead = new BufferedReader(new InputStreamReader(System.in));
	                      // sending to client (pwrite object)
      OutputStream ostream = sock.getOutputStream(); 
      PrintWriter p = new PrintWriter(ostream, true);
 
                              // receiving from server ( receiveRead  object)
      InputStream istream = sock.getInputStream();
      BufferedReader reader = new BufferedReader(new InputStreamReader(istream));
 
      String receiveMessage, sendMessage;
		System.out.println("server :");
      while(true)
      {
        if((receiveMessage = reader.readLine()) != null)  
        {
           System.out.println(receiveMessage);         
        }         
        sendMessage = kRead.readLine(); 
        p.println(sendMessage);             
        p.flush();
      }               
    }
}	