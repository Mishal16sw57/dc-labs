import java.net.*;
import java.io.*;
public class MulticastReceiver  {
    protected static MulticastSocket socket = null;
    protected static byte[] buf = new byte[256];
 
    public static void main(String args[]) throws IOException {
        socket = new MulticastSocket(4446);
        InetAddress group = InetAddress.getByName("230.0.0.0");
        socket.joinGroup(group);
        while (true) {
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            socket.receive(packet);
String message=new String(buf);
System.out.println(message);
            String received = new String(packet.getData(), 0, packet.getLength());
            if ("end".equals(received)) {
                break;
            }
        }
        socket.leaveGroup(group);
        socket.close();
    }
}