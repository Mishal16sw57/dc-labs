import java.net.*;
import java.io.*;
public class ReceiverTask3{
	public static void main(String[] args){
		  // this application sends message using connectionless datagram socket
	 if(args.length!=3)
		 System.out.println("this program requires 3 command line arguments");
	 else{
	 	int port=Integer.parseInt(args[0]);
	 	final int MAX_LEN=100;
		 try{
		 	DatagramSocket mySocket= new DatagramSocket(port);
byte[] buffer= new byte[MAX_LEN];
DatagramPacket datagram= new DatagramPacket(buffer, MAX_LEN);
mySocket.receive(datagram);
String message= new String(buffer);
System.out.println(message);
Thread.sleep(10000);
System.out.print("Exiting");
mySocket.close();


byte[] byte_array=message.getBytes();
byte[] result = new byte[byte_array.length];

for(int i=0; i<byte_array.length;i++)
	result[i]=byte_array[byte_array.length-i-1];
InetAddress receiverHost=InetAddress.getByName(args [1]);
			int receiverPort= Integer.parseInt(args [2]);
				DatagramSocket mySocket1=new DatagramSocket();
			DatagramPacket dp=new DatagramPacket(result,result.length,receiverHost,receiverPort);
			mySocket1.send(dp);

			mySocket1.close();
 }
catch(Exception ex)
{ ex.printStackTrace();
} }}}


