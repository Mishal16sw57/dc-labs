import java.rmi.*;   
  import java.rmi.server.*;   
     
  public class servimpl extends UnicastRemoteObject implements servinterface   
  {   
    public servimpl() throws RemoteException   
    {   
       super();   
    }   
     
    public double addition(double a,double b)   
    {   
       return(a+b);   
    }   
       
    public double subtraction(double a,double b)   
    {   
       return(a-b);   
    }   
       
    public double mulltiple(double a,double b)   
    {   
       return(a*b);   
    }   
       
          
    public double divide(double a,double b)   
    {   
       return(a/b);   
    }   
       
    public double modulus(double a,double b)   
    {   
       return(a%b);   
    }   
       
  }   
     