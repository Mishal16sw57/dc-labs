import java.rmi.*;  
 import java.rmi.server.*;  
   
 public interface servinterface extends Remote  
 {  
      public double addition(double a,double b) throws RemoteException;  
      public double subtraction(double a,double b) throws RemoteException;  
      public double mulltiple(double a,double b) throws RemoteException;  
      public double divide(double a,double b) throws RemoteException;  
      public double modulus(double a,double b) throws RemoteException;  
 }  