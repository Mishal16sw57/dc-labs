import java.rmi.*;
import java.rmi.server.*;
public class Word extends UnicastRemoteObject implements WordCounter{
	int words=0;
	char c=' ';
	public Word() throws RemoteException{}
	public int count(String word) throws RemoteException{
		for(int i=0;i<word.length(); i++){
			c=word.charAt(i);
			if(c==' ')
				words++;
			
			
			System.out.println(""+c);}
			return (words+1);
		}
	}
