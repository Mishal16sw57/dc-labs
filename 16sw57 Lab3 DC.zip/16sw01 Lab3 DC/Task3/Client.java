import java.rmi.*;
import java.rmi.server.*;
import java.util.Scanner;
public class  Client{

	public static void main(String args[]){
		WordCounter word;
		String servername="rmi://localhost/Server";
	Scanner sc = new Scanner(System.in); 
		System.out.println("Enter sentence:");
		String sentence=sc.nextLine();
		try{
			word=(WordCounter)Naming.lookup(servername);
			System.out.println(""+word.count(sentence));
		}catch(Exception e){
			System.out.println("Failed"+e);
		}
	}}