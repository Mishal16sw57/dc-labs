import java.rmi.*;
import java.rmi.server.*;
public class  Server{
	public static void main(String args[]){
		try{
		Naming.rebind("rmi://localhost/Server",new Word());
		System.out.println("Server Ready");
}catch(Exception e){
	System.out.println("Failed"+e);
	}
}
}