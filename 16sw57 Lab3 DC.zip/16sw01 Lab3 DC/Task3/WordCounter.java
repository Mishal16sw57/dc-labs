import java.rmi.*;
public interface WordCounter extends Remote{
	public int count(String word) throws RemoteException;
}