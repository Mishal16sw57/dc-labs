import java.rmi.*;
import java.rmi.server.*;
public class RmiSortServerFix extends UnicastRemoteObject implements RISort {
  public RmiSortServerFix() throws RemoteException { }
  public int[] sort( int[] array ) {
    System.out.print( "RmiSortServerFix.sort() - " );
    for (int i=0; i < array.length; i++) System.out.print( array[i] + " " );
    System.out.println();
    for (int g = array.length/2; g > 0; g /= 2)
      for (int i = g; i < array.length; i++)
        for (int j = i-g; j >= 0; j -= g)
          if (array[j] > array[j+g]) {
            int temp = array[j];
            array[j] = array[j+g];
            array[j+g] = temp;
          }
    return array;
  }}