import java.rmi.*;
import java.rmi.server.*;

interface RISort extends Remote {
  int[] sort( int[] array ) throws RemoteException;
}