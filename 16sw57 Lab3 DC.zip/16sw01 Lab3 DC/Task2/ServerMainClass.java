import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
class ServerMainClass extends RmiSortServerFix{
	public ServerMainClass() throws RemoteException{}

public static void main( String[] args ) {
    try {
      Naming.rebind( "SortServer", new RmiSortServerFix() );
    } catch (java.net.MalformedURLException ex) { ex.printStackTrace();
    } catch (RemoteException ex)                { ex.printStackTrace(); }
    System.out.println( "SortServerFix bound in rmiregistry" );
} }

