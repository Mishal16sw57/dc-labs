import java.net.*;
import java.io.*;
public class ConnectionAcceptor {
	//Two command line arguments are needed
	// port number of the server socket and second is the message to send
	public static void main(String[] args){
		if(args.length!=2){
			System.out.println("This program requires two command line arguments");
		}
		else{
try{
	System.out.println("Aslamoalikum");
				int portNo=Integer.parseInt(args[0]);
				String message=args[1];
				ServerSocket connectionSocket=new ServerSocket(portNo);
				System.out.println("now ready to accept a connection");
				Socket dataSocket=connectionSocket.accept();
				System.out.println("Connection Accepted");
				OutputStream outStream=dataSocket.getOutputStream();
				//create a print writer for character mode output
				PrintWriter socketOutput=new PrintWriter(new OutputStreamWriter(outStream));
				//write a message into the data stream
				socketOutput.println(message);
//the ensuing flush method ensures that data is written into the data socket before the socket is closed.
				socketOutput.flush();
				System.out.println("message sent");
				dataSocket.close();
				System.out.println("data socket closed.");
				connectionSocket.close();
				System.out.println("connection socket closed.");
				Thread.sleep(50000);
			}
	catch(Exception ex){ ex.printStackTrace();
			} } } }
